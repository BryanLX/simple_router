rm -rf pa1.tar.gz
tar czf pa1.tar.gz ./* 
